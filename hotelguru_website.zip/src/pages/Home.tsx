import {useEffect} from "react";
import { Autocomplete } from '@mantine/core';


const Home = () => {

    useEffect(() => {
        loadItems();
    }, []);

    const loadItems = () => {

    }
    return <div>
        <Autocomplete
            label="Város"
            placeholder="Írd be a várost vagy válassz a listából"
            data={['Budapest', 'Balatonfüred', 'Szeged', 'Debrecen', 'Miskolc', 'Pécs']}
        />
    </div>
}

export default Home;