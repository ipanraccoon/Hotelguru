import Login from "../pages/Login.tsx";
import ForgotPassword from "../pages/ForgotPassword.tsx";
import Home from "../pages/Home.tsx";
import Services from "../pages/Services.tsx";
import Reservations from "../pages/Reservations.tsx";
import Invoices from "../pages/Invoices.tsx";
export const routes = [
    {
        path: "login",
        component: <Login/>,
        isPrivate: false
    },
    {
        path: "forgot",
        component: <ForgotPassword/>,
        isPrivate: false
    },
    {
        path: "home",
        component: <Home/>,
        isPrivate: true
    },
    {
        path: "services",
        component: <Services/>,
        isPrivate: true
    },
    {
        path: "reservations",
        component: <Reservations/>,
        isPrivate: true
    },
    {
        path: "invoices",
        component: <Invoices/>,
        isPrivate: true
    },
]