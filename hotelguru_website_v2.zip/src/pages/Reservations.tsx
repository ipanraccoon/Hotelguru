import {Table} from "@mantine/core";

const Reservations = () => {

    const elements = [
        { id: 1, hotel_name: 'Duna Hotel', room_number: 101, room_price: 10000, arrival: '2026-04-02', departure: '2026-04-05',status: 'Folyamatban' },
        { id: 1, hotel_name: 'Duna Hotel', room_number: 101, room_price: 20000, arrival: '2026-04-02', departure: '2026-04-05',status: 'Törölve' },
        { id: 1, hotel_name: 'Duna Hotel', room_number: 101, room_price: 10000, arrival: '2026-04-02', departure: '2026-04-05',status: 'Elfogadva' },
        { id: 1, hotel_name: 'Duna Hotel', room_number: 101, room_price: 10000, arrival: '2026-04-02', departure: '2026-04-05',status: 'Folyamatban' },
    ];

    const rows = elements.map((element) => (
        <Table.Tr key={element.id}>
            <Table.Td>{element.hotel_name}</Table.Td>
            <Table.Td>{element.room_number}</Table.Td>
            <Table.Td>{element.room_price}</Table.Td>
            <Table.Td>{element.arrival}</Table.Td>
            <Table.Td>{element.departure}</Table.Td>
            <Table.Td>{element.status}</Table.Td>
        </Table.Tr>
    ));



    return (
        <Table>
            <Table.Thead>
                <Table.Tr>
                    <Table.Th>Hotel neve</Table.Th>
                    <Table.Th>Szoba száma</Table.Th>
                    <Table.Th>Szoba ára</Table.Th>
                    <Table.Th>Tervezett érkezés</Table.Th>
                    <Table.Th>Tervezett távozás</Table.Th>
                    <Table.Th>Foglalás állapota</Table.Th>
                </Table.Tr>
            </Table.Thead>
            <Table.Tbody>{rows}</Table.Tbody>
        </Table>
    );
}

export default Reservations;