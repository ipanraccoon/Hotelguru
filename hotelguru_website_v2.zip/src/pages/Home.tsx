import {useEffect} from "react";
import { Autocomplete } from '@mantine/core';
import { NumberInput } from '@mantine/core';
import { Button } from '@mantine/core';
import { TextInput } from '@mantine/core';

const Home = () => {

    useEffect(() => {
        loadItems();
    }, []);

    const loadItems = () => {

    }
    return <div>
        <Autocomplete
            label="Város"
            placeholder="Írd be a várost vagy válassz a listából"
            data={['Budapest', 'Balatonfüred', 'Szeged', 'Debrecen', 'Miskolc', 'Pécs']}
        />
        <NumberInput
            label="Fekhelyek száma"
            placeholder="Írj be egy számot"
            defaultValue={1}
            min={1}
            max={35}
        />
        <TextInput
            label="Érkezés"
            placeholder="2026-06-07"
        />
        <TextInput
            label="Távozás"
            placeholder="2026-06-12"
        />
        <Button variant="filled" color="rgba(97, 39, 179, 1)" size="md" radius="lg">Keresés</Button>
    </div>
}

export default Home;