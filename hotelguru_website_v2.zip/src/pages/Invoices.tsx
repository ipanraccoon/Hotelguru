import { Table } from '@mantine/core';

const Invoices = () => {

    const elements = [
        { id: 1, description: 'Szoba 101 - 4 éjszaka', price: 50000},
        { id: 2, description: 'Reggeli', price: 2345},
        { id: 3, description: 'Parkolás', price: 8428},
    ];

    const rows = elements.map((element) => (
        <Table.Tr key={element.id}>
            <Table.Td>{element.description}</Table.Td>
            <Table.Td>{element.price}</Table.Td>
        </Table.Tr>
    ));



    return (
        <Table>
            <Table.Thead>
                <Table.Tr>
                    <Table.Th>Megnevezés</Table.Th>
                    <Table.Th>Ár</Table.Th>
                </Table.Tr>
            </Table.Thead>
            <Table.Tbody>{rows}</Table.Tbody>
        </Table>
    );}

export default Invoices;