import {Autocomplete, Table} from '@mantine/core';
import { MultiSelect } from '@mantine/core';

const Services = () => {

    const elements = [
        { id: 1, hotel_name: 'Duna Hotel', service_name: 'Wellness', service_price: 12000 },
        { id: 2, hotel_name: 'Duna Hotel', service_name: 'Szauna', service_price: 7000 },
        { id: 3, hotel_name: 'Duna Hotel', service_name: 'Parkolás', service_price: 9000 },
        { id: 4, hotel_name: 'Duna Hotel', service_name: 'Wellness', service_price: 12000 },
        { id: 5, hotel_name: 'Duna Hotel', service_name: 'Wellness', service_price: 12000 },
    ];

    const rows = elements.map((element) => (
        <Table.Tr key={element.id}>
            <Table.Td>{element.hotel_name}</Table.Td>
            <Table.Td>{element.service_name}</Table.Td>
            <Table.Td>{element.service_price}</Table.Td>
        </Table.Tr>
    ));



    return <div>
        <Autocomplete
            label="Szűrj a hotel neve szerint"
            placeholder="Írd be a hotel nevét vagy válassz a listából"
            data={['Duna Hotel', 'Balatonfüred', 'Szeged', 'Debrecen', 'mind']}
        />
        <MultiSelect
            label="Szűrj szolgáltatás szerint"
            placeholder="Írd be a szolgáltatást vagy válassz a listából"
            data={['Parkolás', 'Wellness', 'Szauna', 'Étkeztetés']}
        />
        <Table>
            <Table.Thead>
                <Table.Tr>
                    <Table.Th>Hotel neve</Table.Th>
                    <Table.Th>Szolgáltatás neve</Table.Th>
                    <Table.Th>Szolgáltatás ára</Table.Th>
                </Table.Tr>
            </Table.Thead>
            <Table.Tbody>{rows}</Table.Tbody>
        </Table>
    </div>
}

export default Services;